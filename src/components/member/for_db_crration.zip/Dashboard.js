// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import styles from "./Dashboard.module.css";
// import axiosInstance from "../../utility/axiosInstance";
// import { API_URL } from "../../utility/constants";

// import Home from "./Home";
// import Profile from "./Profile";
// import Friends from "./Friends";
// import History from "./History";
// import Groups from "./Groups";
// import Menu from "./Menu";
// import Settings from "./Settings";
// import ProfileImageCapture from "./ProfileImageCapture";
// import {
//   House,
//   User,
//   Users,
//   ListCheck,
//   UsersRound,
//   LogOut,
// } from "lucide-react";

// function Dashboard() {
//   const [activePage, setActivePage] = useState("home");
//   const [user, setUser] = useState(true);
//   const [loading, setLoading] = useState(true);
//   const [isMenuOpen, setIsMenuOpen] = useState(false);
//   const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
//   const [selectedTransaction, setSelectedTransaction] = useState(null);

//   const navigate = useNavigate();

//   const openDetailsPopup = (transaction) => setSelectedTransaction(transaction);
//   const closeDetailsPopup = () => setSelectedTransaction(null);

//   useEffect(() => {
//     const fetchUser = async () => {
//       try {
//         const response = await axiosInstance.get("/api/dashboard");
//         const userData = response.data;
//         setUser(userData);
//         localStorage.setItem("user", JSON.stringify(userData));
//       } catch (err) {
//         console.error("Failed to load dashboard:", err);
//         localStorage.removeItem("accessToken");
//         localStorage.removeItem("user");
//         navigate("/components/member/dashboard");
//       } finally {
//         setLoading(false);
//       }
//     };

//     const savedUser = localStorage.getItem("user");
//     if (savedUser) {
//       setUser(JSON.parse(savedUser));
//     }
//     fetchUser();
//   }, [navigate]);

//   const handleLogout = async () => {
//     try {
//       await axiosInstance.post("/api/logout");
//     } catch (err) {
//       console.warn("Logout API call failed (still logging out locally):", err);
//     } finally {
//       localStorage.removeItem("accessToken");
//       localStorage.removeItem("user");
//       navigate("/components/member/login");
//     }
//   };

//   const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

//   const handleNavClick = (page) => {
//     setActivePage(page);
//     setIsMenuOpen(false);
//     setIsUserMenuOpen(false);
//   };

//   const handleImageCapture = () => {
//     setActivePage("profileImageCapture");
//     setIsUserMenuOpen(false);
//   };

//   const refreshUser = () => {
//     const saved = localStorage.getItem("user");
//     if (saved) {
//       setUser(JSON.parse(saved));
//     }
//     axiosInstance
//       .get("/api/dashboard")
//       .then((res) => {
//         const updatedUser = res.data;
//         setUser(updatedUser);
//         localStorage.setItem("user", JSON.stringify(updatedUser));
//       })
//       .catch(() => {});
//   };

//   if (loading) {
//     return (
//       <div className={styles.loadingContainer}>
//         <div className={styles.loader}></div>
//         <p>Loading Dashboard...</p>
//       </div>
//     );
//   }

//   if (!user) return null;

//   const navItems = [
//     { id: "home", label: "Home", icon: <House size={20} /> },
//     { id: "profile", label: "Profile", icon: <User size={20} /> },
//     { id: "friends", label: "Friends", icon: <Users size={20} /> },
//     { id: "history", label: "History", icon: <ListCheck size={20} /> },
//     { id: "groups", label: "Groups", icon: <UsersRound size={20} /> },
//   ];

//   const renderContent = () => {
//     switch (activePage) {
//       case "home":
//         return <Home onPageChange={handleNavClick} user={user} />;
//       case "profile":
//         return <Profile user={user} onRefreshUser={refreshUser} />;
//       case "friends":
//         return <Friends />;
//       case "history":
//         return (
//           <History
//             selectedTransaction={selectedTransaction}
//             openDetailsPopup={openDetailsPopup}
//             closeDetailsPopup={closeDetailsPopup}
//           />
//         );
//       case "groups":
//         return <Groups />;
//       case "settings":
//         return (
//           <Settings
//             user={user}
//             navigate={navigate}
//             onSuccess={() => handleNavClick("home")}
//           />
//         );
//       case "profileImageCapture":
//         return (
//           <ProfileImageCapture
//             user={user}
//             onRefreshUser={refreshUser}
//             onBack={() => setActivePage("profile")}
//           />
//         );
//       default:
//         return <Home onPageChange={handleNavClick} user={user} />;
//     }
//   };

//   return (
//     <div className={styles.appDashboard}>
//       {/* Sidebar for Desktop */}
//       <aside className={styles.sidebar}>
//         <div className={styles.sidebarHeader}>
//           <img
//             src="/images/payzarc.png"
//             alt="Payzarc"
//             className={styles.sidebarLogo}
//             onClick={() => handleNavClick("home")}
//           />
//         </div>
//         <nav className={styles.sidebarNav}>
//           {navItems.map((item) => (
//             <div
//               key={item.id}
//               className={`${styles.sidebarNavItem} ${activePage === item.id ? styles.active : ""}`}
//               onClick={() => handleNavClick(item.id)}
//             >
//               <svg
//                 fill="currentColor"
//                 stroke="currentColor"
//                 viewBox="0 0 24 24"
//                 className={styles.navIcon}
//               >
//                 {item.icon}
//               </svg>
//               <span>{item.label}</span>
//             </div>
//           ))}
//         </nav>
//         <div className={styles.sidebarFooter}>
//           <div className={styles.sidebarLogout} onClick={handleLogout}>
//             <LogOut className={styles.navIcon} size={20} />
//             <span>Logout</span>
//           </div>
//         </div>
//       </aside>

//       <div className={styles.mainWrapper}>
//         <header className={styles.topBar}>
//           <div className={styles.topBarContent}>
//             <div
//               className={styles.mobileLogo}
//               onClick={() => handleNavClick("home")}
//             >
//               <img
//                 src="/images/payzarc.png"
//                 alt="Payzarc"
//                 className={styles.appLogo}
//               />
//             </div>

//             <div className={styles.topBarActions}>
//               <div className={styles.userInfo}>
//                 <span className={styles.userName}>
//                   {user?.username
//                     ? `@${user.username}`
//                     : user
//                       ? `${user.firstname} ${user.surname}`
//                       : ""}
//                 </span>
//                 <div
//                   className={styles.userAvatarWrapper}
//                   onMouseEnter={() => setIsUserMenuOpen(true)}
//                   onMouseLeave={() => setIsUserMenuOpen(false)}
//                 >
//                   <img
//                     src={
//                       user.profileImageUrl
//                         ? `${API_URL}${user.profileImageUrl}`
//                         : "/images/default-user.png"
//                     }
//                     alt="User"
//                     className={styles.userAvatar}
//                     onError={(e) => {
//                       e.target.src = "/images/default-user.png";
//                     }}
//                   />
//                   {isUserMenuOpen && (
//                     <div className={styles.userDropdown}>
//                       <div
//                         className={styles.dropdownItem}
//                         onClick={handleImageCapture}
//                       >
//                         Update Photo
//                       </div>
//                       <div
//                         className={styles.dropdownItem}
//                         onClick={() => handleNavClick("profile")}
//                       >
//                         Edit Profile
//                       </div>
//                       <div
//                         className={styles.dropdownItem}
//                         onClick={() => handleNavClick("settings")}
//                       >
//                         Settings
//                       </div>
//                       <div
//                         className={`${styles.dropdownItem} ${styles.logout}`}
//                         onClick={handleLogout}
//                       >
//                         Logout
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </header>

//         <main className={styles.mainContent}>
//           <div className={styles.contentContainer}>{renderContent()}</div>
//         </main>

//         {/* Bottom Nav for Mobile */}
//         <nav className={styles.bottomNav}>
//           {navItems.map((item) => (
//             <div
//               key={item.id}
//               className={`${styles.bottomNavItem} ${activePage === item.id ? styles.active : ""}`}
//               onClick={() => handleNavClick(item.id)}
//             >
//               <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                 {item.icon}
//               </svg>
//               <span>{item.label}</span>
//             </div>
//           ))}
//           <Menu
//             isMenuOpen={isMenuOpen}
//             toggleMenu={toggleMenu}
//             handleLogout={handleLogout}
//             navigate={navigate}
//             handleNavClick={handleNavClick}
//           />
//         </nav>
//       </div>
//     </div>
//   );
// }

// export default Dashboard;

// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import styles from "./Dashboard.module.css";
// import axiosInstance from "../../utility/axiosInstance";
// import { API_URL } from "../../utility/constants";

// import Home from "./Home";
// import Profile from "./Profile";
// import Friends from "./Friends";
// import History from "./History";
// import Groups from "./Groups";
// import Menu from "./Menu";
// import Settings from "./Settings";
// import ProfileImageCapture from "./ProfileImageCapture";
// import {
//   House,
//   User,
//   Users,
//   ListCheck,
//   UsersRound,
//   LogOut,
//   Search,
//   Bell,
//   Settings as SettingsIcon,
//   ChevronDown,
// } from "lucide-react";

// function Dashboard() {
//   const [activePage, setActivePage] = useState("home");
//   const [user, setUser] = useState(true);
//   const [loading, setLoading] = useState(true);
//   const [isMenuOpen, setIsMenuOpen] = useState(false);
//   const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
//   const [selectedTransaction, setSelectedTransaction] = useState(null);

//   const navigate = useNavigate();

//   const openDetailsPopup = (transaction) => setSelectedTransaction(transaction);
//   const closeDetailsPopup = () => setSelectedTransaction(null);

//   useEffect(() => {
//     const fetchUser = async () => {
//       try {
//         const response = await axiosInstance.get("/api/dashboard");
//         const userData = response.data;
//         setUser(userData);
//         localStorage.setItem("user", JSON.stringify(userData));
//       } catch (err) {
//         console.error("Failed to load dashboard:", err);
//         localStorage.removeItem("accessToken");
//         localStorage.removeItem("user");
//         navigate("/components/member/dashboard");
//       } finally {
//         setLoading(false);
//       }
//     };

//     const savedUser = localStorage.getItem("user");
//     if (savedUser) {
//       setUser(JSON.parse(savedUser));
//     }
//     fetchUser();
//   }, [navigate]);

//   const handleLogout = async () => {
//     try {
//       await axiosInstance.post("/api/logout");
//     } catch (err) {
//       console.warn("Logout API call failed (still logging out locally):", err);
//     } finally {
//       localStorage.removeItem("accessToken");
//       localStorage.removeItem("user");
//       navigate("/components/member/login");
//     }
//   };

//   const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

//   const handleNavClick = (page) => {
//     setActivePage(page);
//     setIsMenuOpen(false);
//     setIsUserMenuOpen(false);
//   };

//   const handleImageCapture = () => {
//     setActivePage("profileImageCapture");
//     setIsUserMenuOpen(false);
//   };

//   const refreshUser = () => {
//     const saved = localStorage.getItem("user");
//     if (saved) {
//       setUser(JSON.parse(saved));
//     }
//     axiosInstance
//       .get("/api/dashboard")
//       .then((res) => {
//         const updatedUser = res.data;
//         setUser(updatedUser);
//         localStorage.setItem("user", JSON.stringify(updatedUser));
//       })
//       .catch(() => {});
//   };

//   if (loading) {
//     return (
//       <div className={styles.loadingContainer}>
//         <div className={styles.loader}></div>
//         <p>Loading Dashboard...</p>
//       </div>
//     );
//   }

//   if (!user) return null;

//   const navItems = [
//     { id: "home", label: "Home", icon: <House size={20} /> },
//     { id: "profile", label: "Profile", icon: <User size={20} /> },
//     { id: "friends", label: "Friends", icon: <Users size={20} /> },
//     { id: "history", label: "History", icon: <ListCheck size={20} /> },
//     { id: "groups", label: "Groups", icon: <UsersRound size={20} /> },
//     { id: "settings", label: "Settings", icon: <SettingsIcon size={20} /> },
//   ];

//   const renderContent = () => {
//     switch (activePage) {
//       case "home":
//         return <Home onPageChange={handleNavClick} user={user} />;
//       case "profile":
//         return <Profile user={user} onRefreshUser={refreshUser} />;
//       case "friends":
//         return <Friends />;
//       case "history":
//         return (
//           <History
//             selectedTransaction={selectedTransaction}
//             openDetailsPopup={openDetailsPopup}
//             closeDetailsPopup={closeDetailsPopup}
//           />
//         );
//       case "groups":
//         return <Groups />;
//       case "settings":
//         return (
//           <Settings
//             user={user}
//             navigate={navigate}
//             onSuccess={() => handleNavClick("home")}
//           />
//         );
//       case "profileImageCapture":
//         return (
//           <ProfileImageCapture
//             user={user}
//             onRefreshUser={refreshUser}
//             onBack={() => setActivePage("profile")}
//           />
//         );
//       default:
//         return <Home onPageChange={handleNavClick} user={user} />;
//     }
//   };

//   return (
//     <div className={styles.appDashboard}>
//       {/* Sidebar for Desktop */}
//       <aside className={styles.sidebar}>
//         <div className={styles.sidebarHeader}>
//           <img
//             src="/images/payzarc.png"
//             alt="Payzarc"
//             className={styles.sidebarLogo}
//             onClick={() => handleNavClick("home")}
//           />
//         </div>
//         <nav className={styles.sidebarNav}>
//           {navItems.map((item) => (
//             <div
//               key={item.id}
//               className={`${styles.sidebarNavItem} ${activePage === item.id ? styles.active : ""}`}
//               onClick={() => handleNavClick(item.id)}
//             >
//               <svg
//                 fill="currentColor"
//                 stroke="currentColor"
//                 viewBox="0 0 24 24"
//                 className={styles.navIcon}
//               >
//                 {item.icon}
//               </svg>
//               <span>{item.label}</span>
//             </div>
//           ))}
//         </nav>
//         <div className={styles.sidebarFooter}>
//           <div className={styles.sidebarLogout} onClick={handleLogout}>
//             <LogOut className={styles.navIcon} size={20} />
//             <span>Logout</span>
//           </div>
//         </div>
//       </aside>

//       <div className={styles.mainWrapper}>
//         <header className={styles.topBar}>
//           <div className={styles.topBarContent}>
//             <div
//               className={styles.mobileLogo}
//               onClick={() => handleNavClick("home")}
//             >
//               <img
//                 src="/images/payzarc.png"
//                 alt="Payzarc"
//                 className={styles.appLogo}
//               />
//             </div>

//             <div className={styles.searchContainer}>
//               <Search className={styles.searchIcon} size={18} />
//               <input
//                 type="text"
//                 placeholder="Search anything..."
//                 className={styles.searchInput}
//               />
//             </div>

//             <div className={styles.topBarActions}>
//               <div className={styles.notificationWrapper}>
//                 <Bell className={styles.notificationIcon} size={22} />
//                 <span className={styles.notificationBadge}>3</span>
//               </div>
//               <div className={styles.userInfo}>
//                 <div className={styles.userDetails}>
//                   <span className={styles.userName}>
//                     {user?.firstname && user?.surname
//                       ? `${user.firstname} ${user.surname}`
//                       : user?.username || "User"}
//                   </span>
//                   <ChevronDown className={styles.chevronIcon} size={16} />
//                 </div>
//                 <div
//                   className={styles.userAvatarWrapper}
//                   onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
//                 >
//                   <img
//                     src={
//                       user.profileImageUrl
//                         ? `${API_URL}${user.profileImageUrl}`
//                         : "/images/default-user.png"
//                     }
//                     alt="User"
//                     className={styles.userAvatar}
//                     onError={(e) => {
//                       e.target.src = "/images/default-user.png";
//                     }}
//                   />
//                   {isUserMenuOpen && (
//                     <div className={styles.userDropdown}>
//                       <div
//                         className={styles.dropdownItem}
//                         onClick={handleImageCapture}
//                       >
//                         Update Photo
//                       </div>
//                       <div
//                         className={styles.dropdownItem}
//                         onClick={() => handleNavClick("profile")}
//                       >
//                         Edit Profile
//                       </div>
//                       <div
//                         className={styles.dropdownItem}
//                         onClick={() => handleNavClick("settings")}
//                       >
//                         Settings
//                       </div>
//                       <div
//                         className={`${styles.dropdownItem} ${styles.logout}`}
//                         onClick={handleLogout}
//                       >
//                         Logout
//                       </div>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             </div>
//           </div>
//         </header>

//         <main className={styles.mainContent}>
//           <div className={styles.contentContainer}>{renderContent()}</div>
//         </main>

//         {/* Bottom Nav for Mobile */}
//         <nav className={styles.bottomNav}>
//           {navItems.map((item) => (
//             <div
//               key={item.id}
//               className={`${styles.bottomNavItem} ${activePage === item.id ? styles.active : ""}`}
//               onClick={() => handleNavClick(item.id)}
//             >
//               <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
//                 {item.icon}
//               </svg>
//               <span>{item.label}</span>
//             </div>
//           ))}
//           <Menu
//             isMenuOpen={isMenuOpen}
//             toggleMenu={toggleMenu}
//             handleLogout={handleLogout}
//             navigate={navigate}
//             handleNavClick={handleNavClick}
//           />
//         </nav>
//       </div>
//     </div>
//   );
// }

// export default Dashboard;

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./Dashboard.module.css";
import axiosInstance from "../../utility/axiosInstance";
import { API_URL } from "../../utility/constants";

import Home from "./Home";
import Profile from "./Profile";
import Friends from "./Friends";
import History from "./History";
import Groups from "./Groups";
import Menu from "./Menu";
import Settings from "./Settings";
import ProfileImageCapture from "./ProfileImageCapture";
import {
  House,
  User,
  Users,
  ListCheck,
  UsersRound,
  LogOut,
  Search,
  Bell,
  Settings as SettingsIcon,
  ChevronDown,
} from "lucide-react";

function Dashboard() {
  const [activePage, setActivePage] = useState("home");
  const [user, setUser] = useState(true);
  const [loading, setLoading] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [selectedTransaction, setSelectedTransaction] = useState(null);

  const navigate = useNavigate();

  const openDetailsPopup = (transaction) => setSelectedTransaction(transaction);
  const closeDetailsPopup = () => setSelectedTransaction(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const response = await axiosInstance.get("/api/dashboard");
        const userData = response.data;
        setUser(userData);
        localStorage.setItem("user", JSON.stringify(userData));
      } catch (err) {
        console.error("Failed to load dashboard:", err);
        localStorage.removeItem("accessToken");
        localStorage.removeItem("user");
        navigate("/components/member/dashboard");
      } finally {
        setLoading(false);
      }
    };

    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
    fetchUser();
  }, [navigate]);

  const handleLogout = async () => {
    try {
      await axiosInstance.post("/api/logout");
    } catch (err) {
      console.warn("Logout API call failed (still logging out locally):", err);
    } finally {
      localStorage.removeItem("accessToken");
      localStorage.removeItem("user");
      navigate("/components/member/login");
    }
  };

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const handleNavClick = (page) => {
    setActivePage(page);
    setIsMenuOpen(false);
    setIsUserMenuOpen(false);
  };

  const handleImageCapture = () => {
    setActivePage("profileImageCapture");
    setIsUserMenuOpen(false);
  };

  const refreshUser = () => {
    const saved = localStorage.getItem("user");
    if (saved) {
      setUser(JSON.parse(saved));
    }
    axiosInstance
      .get("/api/dashboard")
      .then((res) => {
        const updatedUser = res.data;
        setUser(updatedUser);
        localStorage.setItem("user", JSON.stringify(updatedUser));
      })
      .catch(() => {});
  };

  if (loading) {
    return (
      <div className={styles.loadingContainer}>
        <div className={styles.loader}></div>
        <p>Loading Dashboard...</p>
      </div>
    );
  }

  if (!user) return null;

  const navItems = [
    { id: "home", label: "Home", icon: <House size={20} /> },
    { id: "profile", label: "Profile", icon: <User size={20} /> },
    { id: "friends", label: "Friends", icon: <Users size={20} /> },
    { id: "history", label: "History", icon: <ListCheck size={20} /> },
    { id: "groups", label: "Groups", icon: <UsersRound size={20} /> },
    { id: "settings", label: "Settings", icon: <SettingsIcon size={20} /> },
  ];

  const renderContent = () => {
    switch (activePage) {
      case "home":
        return <Home onPageChange={handleNavClick} user={user} />;
      case "profile":
        return <Profile user={user} onRefreshUser={refreshUser} />;
      case "friends":
        return <Friends />;
      case "history":
        return (
          <History
            selectedTransaction={selectedTransaction}
            openDetailsPopup={openDetailsPopup}
            closeDetailsPopup={closeDetailsPopup}
          />
        );
      case "groups":
        return <Groups />;
      case "settings":
        return (
          <Settings
            user={user}
            navigate={navigate}
            onSuccess={() => handleNavClick("home")}
          />
        );
      case "profileImageCapture":
        return (
          <ProfileImageCapture
            user={user}
            onRefreshUser={refreshUser}
            onBack={() => setActivePage("profile")}
          />
        );
      default:
        return <Home onPageChange={handleNavClick} user={user} />;
    }
  };

  return (
    <div className={styles.appDashboard}>
      {/* Sidebar for Desktop */}
      <aside className={styles.sidebar}>
        <div className={styles.sidebarHeader}>
          <img
            src="/images/payzarc.png"
            alt="Payzarc"
            className={styles.sidebarLogo}
            onClick={() => handleNavClick("home")}
          />
        </div>
        <nav className={styles.sidebarNav}>
          {navItems.map((item) => (
            <div
              key={item.id}
              className={`${styles.sidebarNavItem} ${activePage === item.id ? styles.active : ""}`}
              onClick={() => handleNavClick(item.id)}
            >
              <svg
                fill="currentColor"
                stroke="currentColor"
                viewBox="0 0 24 24"
                className={styles.navIcon}
              >
                {item.icon}
              </svg>
              <span>{item.label}</span>
            </div>
          ))}
        </nav>
        <div className={styles.sidebarFooter}>
          <div className={styles.sidebarLogout} onClick={handleLogout}>
            <LogOut className={styles.navIcon} size={20} />
            <span>Logout</span>
          </div>
        </div>
      </aside>

      <div className={styles.mainWrapper}>
        <header className={styles.topBar}>
          <div className={styles.topBarContent}>
            <div
              className={styles.mobileLogo}
              onClick={() => handleNavClick("home")}
            >
              <img
                src="/images/payzarc.png"
                alt="Payzarc"
                className={styles.appLogo}
              />
            </div>

            <div className={styles.searchContainer}>
              <Search className={styles.searchIcon} size={18} />
              <input
                type="text"
                placeholder="Search anything..."
                className={styles.searchInput}
              />
            </div>

            <div className={styles.topBarActions}>
              <div className={styles.notificationWrapper}>
                <Bell className={styles.notificationIcon} size={22} />
                <span className={styles.notificationBadge}>3</span>
              </div>
              <div className={styles.userInfo}>
                <div className={styles.userDetails}>
                  <span className={styles.userName}>
                    {user?.firstname && user?.surname
                      ? `${user.firstname} ${user.surname}`
                      : user?.username || ""}
                  </span>
                  <ChevronDown className={styles.chevronIcon} size={16} />
                </div>
                <div
                  className={styles.userAvatarWrapper}
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                >
                  <img
                    src={
                      user.profileImageUrl
                        ? `${API_URL}${user.profileImageUrl}`
                        : "/images/default-user.png"
                    }
                    alt="User"
                    className={styles.userAvatar}
                    onError={(e) => {
                      e.target.src = "/images/default-user.png";
                    }}
                  />
                  {isUserMenuOpen && (
                    <div className={styles.userDropdown}>
                      <div
                        className={styles.dropdownItem}
                        onClick={handleImageCapture}
                      >
                        Update Photo
                      </div>
                      <div
                        className={styles.dropdownItem}
                        onClick={() => handleNavClick("profile")}
                      >
                        Edit Profile
                      </div>
                      <div
                        className={styles.dropdownItem}
                        onClick={() => handleNavClick("settings")}
                      >
                        Settings
                      </div>
                      <div
                        className={`${styles.dropdownItem} ${styles.logout}`}
                        onClick={handleLogout}
                      >
                        Logout
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className={styles.mainContent}>
          <div className={styles.contentContainer}>{renderContent()}</div>
        </main>

        {/* Bottom Nav for Mobile */}
        <nav className={styles.bottomNav}>
          {navItems.map((item) => (
            <div
              key={item.id}
              className={`${styles.bottomNavItem} ${activePage === item.id ? styles.active : ""}`}
              onClick={() => handleNavClick(item.id)}
            >
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                {item.icon}
              </svg>
              <span>{item.label}</span>
            </div>
          ))}
          <Menu
            isMenuOpen={isMenuOpen}
            toggleMenu={toggleMenu}
            handleLogout={handleLogout}
            navigate={navigate}
            handleNavClick={handleNavClick}
          />
        </nav>
      </div>
    </div>
  );
}

export default Dashboard;
