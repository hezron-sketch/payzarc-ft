import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  Paperclip,
  Plus,
  ArrowUpIcon,
  Users,
  Eye,
  EyeOff,
  ChevronRight,
  Handshake,
  Tv,
  Briefcase,
  ShoppingCart,
  University,
  TrendingUp,
  TrendingDown,
  ArrowDown,
  ArrowDownIcon,
  Send,
} from "lucide-react";
import { transactionsApi, contactsApi } from "../../utility/axiosInstance";
import axios from "axios";

import styles from "./Home.module.css";
import YesNoPopup from "../../styles/YesNoPopup";
import { countries } from "../../utility/countries";
import { djangoApis } from "../../utility/axiosInstance";
import { API_URL } from "../../utility/constants";

function Option({ icon, text, onClick }) {
  return (
    <div className={styles.option} onClick={onClick}>
      <FontAwesomeIcon icon={icon} className={styles.optionIcon} />
      <span className={styles.optionText}>{text}</span>
    </div>
  );
}

function Home({ onPageChange, user }) {
  const [activeSection, setActiveSection] = useState("dashboard");
  const [withdrawOption, setWithdrawOption] = useState("");
  const [emailSearchTerm, setEmailSearchTerm] = useState("");
  const [selectedEmail, setSelectedEmail] = useState("");
  const [sendAmount, setSendAmount] = useState("");
  const [withdrawAmount, setWithdrawAmount] = useState("");
  const [agentNumber, setAgentNumber] = useState("");
  const [selectedAccount, setSelectedAccount] = useState("");
  const [addAmount, setAddAmount] = useState("");
  const [addSelectedAccount, setAddSelectedAccount] = useState("");
  const [errorWallet, setErrorWallet] = useState("");
  const [openDialog, setOpenDialog] = useState(false);
  const [dialogTitle, setDialogTitle] = useState("");
  const [dialogMessage, setDialogMessage] = useState("");
  const [dialogAction, setDialogAction] = useState(null);
  const [selectedAddOption, setSelectedAddOption] = useState("");
  const [showAddInput, setShowAddInput] = useState(false);
  const [showWithdrawOptions, setShowWithdrawOptions] = useState(false);
  const [sendMethod, setSendMethod] = useState("");
  const [selectedCountryCode, setSelectedCountryCode] = useState("");
  const [phoneSearchTerm, setPhoneSearchTerm] = useState("");
  const [fullPhone, setFullPhone] = useState("");
  const [mobileMoneySelected, setMobileMoneySelected] = useState(false);
  const [mobileMoneyWithdrawSelected, setMobileMoneyWithdrawSelected] =
    useState(false);
  const [showBalance, setShowBalance] = useState(false);
  const [animateKey, setAnimateKey] = useState(0);
  const [bottomView, setBottomView] = useState("transactions");

  // ───────────────────────────────────────────────
  // States for real balance from Django
  // ───────────────────────────────────────────────
  const [balanceData, setBalanceData] = useState(null);
  const [loadingBalance, setLoadingBalance] = useState(true);
  const [balanceError, setBalanceError] = useState(null);
  // ───────────────────────────────────────────────
  // States for real balance from Django
  // ───────────────────────────────────────────────

  //---------------------------------------------------
  const [quickRecipient, setQuickRecipient] = useState("");
  const [quickAmount, setQuickAmount] = useState("");

  //-----------------------------------------------------------
  // Add Recipient states
  const [recipientName, setRecipientName] = useState("");
  const [recipientLabel, setRecipientLabel] = useState("");
  const [recipientCountryCode, setRecipientCountryCode] = useState("+254"); // Default Kenya
  const [recipientPhone, setRecipientPhone] = useState("");
  const [recipientType, setRecipientType] = useState("email"); // 'email' | 'phone'
  const [recipientEmail, setRecipientEmail] = useState("");
  const [emailError, setEmailError] = useState("");
  const [labelError, setLabelError] = useState("");
  const [loading, setLoading] = useState(false);
  const [myPhone, setMyPhone] = useState(null);

  // Replace or add these lines near your other useState declarations

  const [recipientSearchTerm, setRecipientSearchTerm] = useState("");
  const [selectedRecipient, setSelectedRecipient] = useState(null); // { type: 'email'|'phone', value: string }

  const [favourites, setFavourites] = useState([]); // list from API
  const [loadingFavourites, setLoadingFavourites] = useState(false);
  const [favouritesError, setFavouritesError] = useState(null);

  // PIN Verification for transactions
  const [pinVerificationError, setPinVerificationError] = useState("");
  const [verifyingPin, setVerifyingPin] = useState(false);
  const [showPinInput, setShowPinInput] = useState(false); // Eye toggle
  const [notificationOnly, setNotificationOnly] = useState(false);
  const [inputPin, setInputPin] = useState("");
  const [showInputPin, setShowInputPin] = useState(false);

  //const sortedCountries = [...countries].sort((a, b) => a.name.localeCompare(b.name));
  // Sort countries by dial code numerically ascending
  const sortedCountries = [...countries].sort((a, b) => {
    const codeA = parseInt(a.code.slice(1)); // Remove '+' and convert to number
    const codeB = parseInt(b.code.slice(1));
    return codeA - codeB;
  });
  const [quickDestinationCountry, setQuickDestinationCountry] = useState(
    sortedCountries.find((c) => c.name === "Kenya") || sortedCountries[0],
  );

  // Mock exchange rates and currency codes (add more as needed)
  const exchangeRates = {
    Kenya: { rate: 129.5, currency: "KES" },
    "United States": { rate: 1, currency: "USD" },
    "United Kingdom": { rate: 0.78, currency: "GBP" },
    Canada: { rate: 1.36, currency: "CAD" },
    // Add more countries here if desired
  };

  // Get rate and currency for selected country (fallback to USD)
  const destInfo = exchangeRates[quickDestinationCountry.name] || {
    rate: 1,
    currency: "USD",
  };
  const equivalentAmount = quickAmount
    ? (parseFloat(quickAmount) * destInfo.rate).toFixed(2)
    : "0.00";

  const emails = [
    "ahi.appoli@gmail.com",
    "ajoseph@payzarc.com",
    "amogezi@payzarc.com",
  ];
  const phonesByCountry = {
    "+1": ["8323302962", "8323302963"],
    "+254": ["711194068", "703133119"],
  };

  const emailFilteredEmails = emails.filter((email) =>
    email.toLowerCase().startsWith(emailSearchTerm.toLowerCase()),
  );
  const filteredPhones = (phonesByCountry[selectedCountryCode] || []).filter(
    (phone) => phone.toLowerCase().startsWith(phoneSearchTerm.toLowerCase()),
  );

  const toggleBalance = () => {
    setShowBalance((prev) => !prev);
    setAnimateKey((prev) => prev + 1); // forces remount / re-animation
  };

  // Helper to format balance safely
  const formattedBalance = balanceData
    ? Number(balanceData.balance).toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })
    : "0.00";

  // Reset form fields when user changes
  useEffect(() => {
    setActiveSection("dashboard");
    setWithdrawOption("");
    setEmailSearchTerm("");
    setSelectedEmail("");
    setSendAmount("");
    setWithdrawAmount("");
    setAgentNumber("");
    setSelectedAccount("");
    setAddAmount("");
    setAddSelectedAccount("");
    setErrorWallet("");
    setOpenDialog(false);
    setDialogTitle("");
    setDialogMessage("");
    setDialogAction(null);
    setSelectedAddOption("");
    setShowAddInput(false);
    setShowWithdrawOptions(false);
    setSendMethod("");
    setSelectedCountryCode("");
    setPhoneSearchTerm("");
    setFullPhone("");
    setMobileMoneySelected(false);
    setMobileMoneyWithdrawSelected(false);
  }, [user]);

  useEffect(() => {
    const fetchMyContact = async () => {
      try {
        // const res = await djangoAxios.get('/api/my-contact/');
        const res = await contactsApi.get("/api/my-contact/");
        if (res.data.success) {
          setMyPhone(res.data.phone);
        }
      } catch (e) {}
    };
    fetchMyContact();
  }, []);

  const handleSavePhoneRecipient = async () => {
    const fullPhone = recipientCountryCode + recipientPhone.replace(/^0+/, "");
    if (!fullPhone || fullPhone.length < 10) {
      alert(
        "Please enter a valid phone number (at least 10 digits after country code)",
      );
      return;
    }
    if (myPhone && fullPhone === myPhone) {
      alert("You cannot add your own phone number as a favorite.");
      return;
    }

    setLoading(true);

    try {
      // Step 1: Check
      //const checkRes = await djangoAxios.post('/api/check/', {
      const checkRes = await contactsApi.post("/api/check/", {
        type: "phone",
        value: fullPhone,
      });
      alert(checkRes.data.message || "Check complete");

      // Step 2: Save
      //const saveRes = await djangoAxios.post('/api/favorite/add/', {
      const saveRes = await contactsApi.post("/api/favorite/add/", {
        favourite_type: "phone",
        favourite_detail: fullPhone,
        label: recipientLabel.trim(),
      });

      if (saveRes.status === 201) {
        alert("Phone recipient added successfully!");
        handleAddRecipientBack();
      } else {
        alert(`Unexpected status: ${saveRes.status}`);
      }
    } catch (err) {
      console.error("SAVE PHONE ERROR:", err); // ← see full details in browser console (F12)
      let errorMessage = "Failed to save phone recipient";
      if (err.response?.data) {
        const data = err.response.data;
        // Try to extract the first useful error message
        if (typeof data === "object" && data !== null) {
          // Common Django patterns
          if (data.non_field_errors && Array.isArray(data.non_field_errors)) {
            errorMessage = data.non_field_errors[0];
          } else if (
            data.favourite_detail &&
            Array.isArray(data.favourite_detail)
          ) {
            errorMessage = data.favourite_detail[0];
          } else if (
            data.favourite_type &&
            Array.isArray(data.favourite_type)
          ) {
            errorMessage = data.favourite_type[0];
          } else if (data.label && Array.isArray(data.label)) {
            errorMessage = data.label[0];
          } else if (data.error) {
            errorMessage = data.error;
          } else if (data.detail) {
            errorMessage = data.detail;
          } else {
            // Fallback: show the whole object as string
            errorMessage = JSON.stringify(data, null, 2);
          }
        } else {
          errorMessage =
            String(data) || err.message || "Server returned unknown error";
        }

        // Add status code for context
        errorMessage += ` (HTTP ${err.response.status})`;
      } else if (err.request) {
        errorMessage =
          "No response from server – is Django running? Network issue?";
      } else {
        errorMessage = err.message || "Unknown error";
      }

      alert(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  const validateEmailField = () => {
    if (!recipientEmail) {
      setEmailError("Email is required");
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(recipientEmail)) {
      setEmailError("Please enter a valid email");
      return false;
    }
    if (recipientEmail.length < 10 || recipientEmail.length > 30) {
      setEmailError("Email must be 10–30 characters");
      return false;
    }
    setEmailError("");
    return true;
  };

  const validateLabel = () => {
    const trimmed = recipientLabel.trim();
    if (!trimmed) {
      setLabelError("Label is required");
      return false;
    }
    if (trimmed.length < 3 || trimmed.length > 15) {
      setLabelError("Label must be 3–15 characters");
      return false;
    }
    if (!/^[a-zA-Z0-9\s]+$/.test(trimmed)) {
      setLabelError("Only letters, numbers and spaces allowed");
      return false;
    }
    setLabelError("");
    return true;
  };

  const handleSaveEmailRecipient = async () => {
    if (!validateEmailField() || !validateLabel()) return;

    setLoading(true);

    try {
      // Step 1: Check
      //const checkRes = await djangoAxios.post('/api/check/', {
      const checkRes = await contactsApi.post("/api/check/", {
        type: "email",
        value: recipientEmail, // ← consistent format
      });
      const { is_registered, message } = checkRes.data;
      alert(
        message ||
          (is_registered ? "Email already registered" : "Email not registered"),
      );

      // Step 2: Save
      //const saveRes = await djangoAxios.post('/api/favorite/add/', {
      const saveRes = await contactsApi.post("/api/favorite/add/", {
        favourite_type: "email",
        favourite_detail: recipientEmail,
        label: recipientLabel.trim(),
      });

      if (saveRes.status === 201) {
        alert("Recipient added successfully!");
        setRecipientEmail("");
        setRecipientLabel("");
        setEmailError("");
        setLabelError("");
        handleAddRecipientBack();
      } else {
        alert(`Unexpected status: ${saveRes.status}`);
      }
    } catch (err) {
      console.error("SAVE EMAIL ERROR:", err);

      let errorMessage = "Failed to add email recipient";

      if (err.response?.data) {
        const data = err.response.data;

        if (typeof data === "object" && data !== null) {
          if (data.non_field_errors && Array.isArray(data.non_field_errors)) {
            errorMessage = data.non_field_errors[0];
          } else if (
            data.favourite_detail &&
            Array.isArray(data.favourite_detail)
          ) {
            errorMessage = data.favourite_detail[0];
          } else if (
            data.favourite_type &&
            Array.isArray(data.favourite_type)
          ) {
            errorMessage = data.favourite_type[0];
          } else if (data.label && Array.isArray(data.label)) {
            errorMessage = data.label[0];
          } else if (data.error) {
            errorMessage = data.error;
          } else if (data.detail) {
            errorMessage = data.detail;
          } else {
            errorMessage = JSON.stringify(data, null, 2);
          }
        } else {
          errorMessage =
            String(data) || err.message || "Server returned unknown error";
        }

        errorMessage += ` (HTTP ${err.response.status})`;
      } else if (err.request) {
        errorMessage = "No response from server – check Django is running";
      } else {
        errorMessage = err.message || "Unknown error";
      }

      alert(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // ───────────────────────────────────────────────
  // Fetch real wallet balance from Django
  // ───────────────────────────────────────────────
  //--------------------------------------------------------------------------
  // Define fetchBalance as a normal function in the component
  const fetchBalance = async () => {
    if (!user?.email) {
      setLoadingBalance(false);
      return;
    }
    try {
      console.log("Sending request to /api/balance/");
      console.log(
        "Token from localStorage:",
        localStorage.getItem("accessToken"),
      );
      console.log("Full headers:", transactionsApi.defaults.headers);
      const response = await transactionsApi.get("/api/balance/");
      const data = response.data;
      if (data.success !== undefined) {
        setBalanceData(data);
      } else {
        setBalanceError(data.error || "Failed to load balance");
      }
    } catch (err) {
      console.error("Balance fetch failed:", err);
      if (err.response?.status === 404) {
        setBalanceError("No wallet found for this account.");
      } else {
        setBalanceError("Could not load wallet balance");
      }
    } finally {
      setLoadingBalance(false);
    }
  };

  // Now call it in useEffect (initial load + user change)
  useEffect(() => {
    setLoadingBalance(true);
    setBalanceError(null);
    setBalanceData(null);
    fetchBalance();
  }, [user]);

  const fetchFavourites = async (searchQuery = "") => {
    if (!searchQuery.trim()) {
      setFavourites([]);
      return;
    }

    setLoadingFavourites(true);
    setFavouritesError(null);

    try {
      // Decide type based on input pattern
      let favType = "phone";
      if (
        /^[a-zA-Z]/.test(searchQuery) || // starts with letter
        searchQuery.includes("@") // contains @
      ) {
        favType = "email";
      } else if (
        searchQuery.startsWith("+") ||
        /^\d/.test(searchQuery) // starts with digit
      ) {
        favType = "phone";
      } else {
        // unclear → skip fetch or default to phone
        setFavourites([]);
        setLoadingFavourites(false);
        return;
      }

      const response = await contactsApi.get("/api/favorites/", {
        params: {
          type: favType,
          query: searchQuery,
        },
      });

      if (response.data.success) {
        setFavourites(response.data.favourites || []);
      } else {
        setFavouritesError(
          response.data.message || "Failed to load favourites",
        );
        setFavourites([]);
      }
    } catch (err) {
      console.error("Favourites fetch error:", err);
      setFavouritesError("Could not load favourite contacts");
      setFavourites([]);
    } finally {
      setLoadingFavourites(false);
    }
  };

  //------------///////////////////////////////////////
  const handleAddRecipientBack = () => {
    setActiveSection("dashboard");
    // Clear form
    setRecipientName("");
    setRecipientLabel("");
    setRecipientCountryCode("+254");
    setRecipientPhone("");
  };

  const handleSaveRecipient = () => {
    if (
      !recipientName.trim() ||
      !recipientPhone.trim() ||
      recipientPhone.length < 9
    ) {
      alert("Please enter a valid name and phone number");
      return;
    }
    const fullPhone = recipientCountryCode + recipientPhone;

    // Placeholder save (you can later connect to backend or localStorage array)
    alert(
      `Recipient saved!\nName: ${recipientName}\nPhone: ${fullPhone}\nLabel: ${recipientLabel || "None"}`,
    );

    // Clear and go back
    handleAddRecipientBack();
  };

  // ───────────────────────────────────────────────
  // Your existing handlers (unchanged)
  // ───────────────────────────────────────────────
  const handleQuickSend = () => {
    const amount = parseFloat(quickAmount);
    if (!quickRecipient.trim() || isNaN(amount) || amount <= 0) {
      alert("Please enter a valid recipient and amount");
      return;
    }
    openConfirmationDialog(
      "Confirm Quick Send",
      `Send ${amount.toFixed(2)} USD (${equivalentAmount} ${destInfo.currency}) to ${quickRecipient} in ${quickDestinationCountry.name}?`,
      () => alert("Quick Send processed! (Connect to backend API here)"),
    );
  };

  const handleEmailSearchChange = (e) => {
    setErrorWallet("");
    setEmailSearchTerm(e.target.value);
    setSendAmount("");
    setSelectedEmail("");
  };

  const handleWithdrawOption = (option) => {
    if (option === "mobileMoney") {
      setMobileMoneyWithdrawSelected(true);
    } else {
      setWithdrawOption(option);
      setMobileMoneyWithdrawSelected(false);
      setShowWithdrawOptions(false);
      setWithdrawAmount("");
      setAgentNumber("");
      setSelectedAccount("");
      setSelectedCountryCode("");
      setPhoneSearchTerm("");
      setFullPhone("");
    }
  };

  const handleMobileMoneyWithdrawOptionSelect = (option) => {
    setWithdrawOption(option);
    setMobileMoneyWithdrawSelected(false);
    setShowWithdrawOptions(false);
    setWithdrawAmount("");
    setAgentNumber("");
    setSelectedAccount("");
    setSelectedCountryCode("");
    setPhoneSearchTerm("");
    setFullPhone("");
  };

  const handleEmailSelect = (email) => {
    setSelectedEmail(email);
    setEmailSearchTerm("");
  };

  const handleAddOptionSelect = (option) => {
    if (option === "mobileMoney") {
      setMobileMoneySelected(true);
    } else {
      setSelectedAddOption(option);
      setShowAddInput(true);
      setMobileMoneySelected(false);
      setAgentNumber("");
      setAddAmount("");
      setAddSelectedAccount("");
    }
  };

  const handleMobileMoneyOptionSelect = (option) => {
    setSelectedAddOption(option);
    setShowAddInput(true);
    setMobileMoneySelected(false);
    setAgentNumber("");
    setAddAmount("");
    setAddSelectedAccount("");
  };

  const handleAddMoneyBack = () => {
    if (
      showAddInput &&
      (selectedAddOption === "mpesa" || selectedAddOption === "airtel")
    ) {
      setShowAddInput(false);
      setSelectedAddOption("");
      setAddAmount("");
      setAddSelectedAccount("");
      setAgentNumber("");
      setSelectedCountryCode("");
      setPhoneSearchTerm("");
      setFullPhone("");
      setMobileMoneySelected(true);
    } else if (showAddInput) {
      setShowAddInput(false);
      setSelectedAddOption("");
      setAddAmount("");
      setAddSelectedAccount("");
      setAgentNumber("");
      setMobileMoneySelected(false);
    } else if (mobileMoneySelected) {
      setMobileMoneySelected(false);
    } else {
      setActiveSection("dashboard");
    }
  };

  const handleWithdrawBack = () => {
    if (
      withdrawOption &&
      (withdrawOption === "safiricom" || withdrawOption === "airtel")
    ) {
      setWithdrawOption("");
      setMobileMoneyWithdrawSelected(true);
      setShowWithdrawOptions(false);
      setWithdrawAmount("");
      setAgentNumber("");
      setSelectedAccount("");
      setSelectedCountryCode("");
      setPhoneSearchTerm("");
      setFullPhone("");
    } else if (withdrawOption) {
      setWithdrawOption("");
      setShowWithdrawOptions(true);
      setWithdrawAmount("");
      setAgentNumber("");
      setSelectedAccount("");
      setSelectedCountryCode("");
      setPhoneSearchTerm("");
      setFullPhone("");
    } else if (mobileMoneyWithdrawSelected) {
      setMobileMoneyWithdrawSelected(false);
      setShowWithdrawOptions(true);
    } else {
      setActiveSection("dashboard");
      setShowWithdrawOptions(false);
    }
  };

  const handleSendBack = () => {
    setRecipientSearchTerm("");
    setSelectedRecipient(null);
    setSendAmount("");
    setErrorWallet("");
    setActiveSection("dashboard");
  };

  const openConfirmationDialog = (title, message, action) => {
    setDialogTitle(title);
    setDialogMessage(message);
    setDialogAction(() => action);
    setOpenDialog(true);
  };

  const handleDialogConfirm = (typedValue, buttonChoice) => {
    setOpenDialog(false);

    if (dialogAction) {
      dialogAction(typedValue, buttonChoice); // Pass both values
    } else {
      showNotification("error", "Transaction cancelled");
      clearFields();
    }
  };

  const handleDialogCancel = () => {
    setOpenDialog(false);
    setNotificationOnly(false); // 👈 reset
    if (!notificationOnly) {
      showNotification("error", "Transaction cancelled");
      // alert('Transaction cancelled');
    }

    clearFields();
  };

  const clearFields = () => {
    setErrorWallet("");
    setEmailSearchTerm("");
    setSendAmount("");
    setSelectedEmail("");
    setPhoneSearchTerm("");
    setFullPhone("");
    setSelectedCountryCode("");
  };

  const isValidAmount = (amount) => {
    return (
      amount &&
      !isNaN(parseInt(amount)) &&
      parseInt(amount) >= 1 &&
      parseInt(amount) <= 500000
    );
  };

  const isValidRecipient = (value) => {
    if (!value) return false;
    // very basic check – improve later with real validation
    return value.length >= 6 && value.length <= 60;
  };

  const isSendButtonDisabled = () => {
    if (sendMethod === "email") {
      return !isValidAmount(sendAmount) || !isValidRecipient(selectedEmail);
    } else if (sendMethod === "phone") {
      return !isValidAmount(sendAmount) || !isValidRecipient(fullPhone);
    }
    return true;
  };

  const isAddMoneyButtonDisabled = () => {
    if (selectedAddOption === "bank") {
      return !isValidAmount(addAmount) || !addSelectedAccount;
    } else if (selectedAddOption === "payzarc") {
      return !isValidAmount(addAmount) || !agentNumber;
    } else if (
      selectedAddOption === "mpesa" ||
      selectedAddOption === "airtel"
    ) {
      return !isValidAmount(addAmount) || !isValidRecipient(fullPhone);
    }
    return !isValidAmount(addAmount);
  };

  const isWithdrawButtonDisabled = () => {
    if (withdrawOption === "atm") {
      return !isValidAmount(withdrawAmount) || !selectedAccount;
    } else if (withdrawOption === "safiricom" || withdrawOption === "airtel") {
      return !isValidAmount(withdrawAmount) || !isValidRecipient(fullPhone);
    } else if (withdrawOption === "payzarcAgent") {
      return !isValidAmount(withdrawAmount) || !agentNumber;
    }
    return true;
  };

  const handleSendMoney = async () => {
    if (
      !selectedRecipient ||
      !isValidAmount(sendAmount) ||
      inputPin.length !== 4
    ) {
      setErrorWallet("Enter recipient, valid amount and 4-digit PIN");
      return;
    }
    const token = localStorage.getItem("accessToken");
    const pho = selectedRecipient.value; //.replace("+254", "0");
    openConfirmationDialog(
      "Confirm Send Money",
      `Send ${sendAmount} to ${pho}?\n\nType 1 and click Yes to confirm.`,
      async (typedValue, buttonChoice) => {
        // Only proceed if user typed 1 and clicked Yes
        if (typedValue !== "1" || buttonChoice !== "yes") {
          showNotification("error", "Transaction cancelled");
          return;
        }
        try {
          console.log(
            "Attempting to send money to: " + pho,
            "Amount: ",
            sendAmount,
            "Pin: ",
            inputPin,
            "Token: ",
            token,
          );
          const response = await transactionsApi.post(
            "/api/send-money/",
            {
              recipient_number: pho,
              amount: parseFloat(sendAmount),
              transaction_pin: inputPin,
            },
            {
              headers: { Authorization: `Bearer ${token}` },
            },
          );
          // alert(response.data.message);
          showNotification(
            "success",
            response.data.message || "Money sent successfully!",
          );
          fetchBalance();
          setRecipientSearchTerm("");
          setSelectedRecipient(null);
          setSendAmount("");
          setErrorWallet("");
          setInputPin("");
        } catch (error) {
          // alert(error.response?.data?.error || "Transfer failed");
          const errorMsg =
            error.response?.data?.message ||
            error.response?.data?.error ||
            error.message ||
            "Unknown error";
          showNotification("error", `Transfer failed: ${errorMsg}`);
        }
      },
    );
  };

  const showNotification = (type, message) => {
    setDialogTitle(type === "success" ? "Success" : "Error");
    setDialogMessage(message);
    setNotificationOnly(true);
    setOpenDialog(true);
  };

  // ==================== PAYZARC AGENT WITHDRAW ====================
  const handlePayzarcAgentWithdraw = async () => {
    // Validation before opening confirmation
    if (
      !agentNumber ||
      !isValidAmount(withdrawAmount) ||
      inputPin.length !== 4
    ) {
      alert(
        "Please enter a valid agent number, amount (at least 1) and 4-digit PIN",
      );
      return;
    }

    openConfirmationDialog(
      "Confirm Payzarc Agent Withdrawal",
      `Withdraw ${withdrawAmount} via Payzarc Agent ${agentNumber}?\n\nType 1 and click Yes to confirm.`,
      async (typedValue, buttonChoice) => {
        // Receive both parameters
        // Only proceed if user typed 1 and clicked Yes
        if (typedValue !== "1" || buttonChoice !== "yes") {
          showNotification("error", "Transaction cancelled");
          return;
        }

        try {
          console.log("=== PAYZARC WITHDRAW REQUEST ===");
          console.log("Transaction PIN used:", inputPin);
          console.log("Payload being sent:", {
            agent_number: agentNumber.trim(),
            amount: Number(withdrawAmount),
            transaction_pin: inputPin,
          });

          // const response = await djangoApis.system1.post('/api/withdraw/', {
          //   agent_number: agentNumber.trim(),
          //   amount: Number(withdrawAmount),
          //   transaction_pin: inputPin,
          // });
          const token = localStorage.getItem("accessToken");
          const response = await transactionsApi.post(
            "/api/withdraw/",
            {
              agent_number: agentNumber.trim(),
              amount: Number(withdrawAmount),
              transaction_pin: inputPin,
            },
            {
              headers: { Authorization: `Bearer ${token}` },
            },
          );

          console.log("Backend Response:", response.data);

          // Handle current placeholder response from backend
          const msg = response.data.message || "Withdrawal request submitted";

          showNotification("success", msg);

          // Clear form on success
          fetchBalance();
          setWithdrawAmount("");
          setAgentNumber("");
          setInputPin("");
          setActiveSection("dashboard");
        } catch (err) {
          console.error("Withdrawal Error:", err);

          let errorMsg = "Server error";
          if (err.response?.data?.message) {
            errorMsg = err.response.data.message;
          } else if (err.response?.data) {
            errorMsg = JSON.stringify(err.response.data);
          } else if (err.message) {
            errorMsg = err.message;
          }
          showNotification("error", `Withdrawal failed: ${errorMsg}`);
        }
      },
    );
  };

  const handleWithdraw = () => {
    if (withdrawOption === "payzarcAgent") {
      handlePayzarcAgentWithdraw();
      return;
    }
    // Other withdrawal types (ATM, Safaricom, etc.) - keep placeholder for now
    alert(
      `Withdrawal of ${withdrawAmount} via ${withdrawOption} — Backend call goes here`,
    );
  };

  const handleAddMoney = () => {
    if (
      !addAmount ||
      (selectedAddOption === "bank" && !addSelectedAccount) ||
      (selectedAddOption === "payzarc" && !agentNumber) ||
      ((selectedAddOption === "mpesa" || selectedAddOption === "airtel") &&
        !isValidRecipient(fullPhone))
    ) {
      alert("Please fill in all required fields");
      return;
    }
    openConfirmationDialog(
      "Confirm Add Money",
      `Are you adding ${addAmount} from ${selectedAddOption}${
        selectedAddOption === "bank"
          ? ` account ${addSelectedAccount}`
          : selectedAddOption === "payzarc"
            ? ` agent ${agentNumber}`
            : ` phone ${fullPhone}`
      }?\nYes or 1 to confirm,\nNo or 2 to cancel.`,
      () => alert("Connecting to backend API"),
    );
  };

  const getWithdrawTitle = () => {
    switch (withdrawOption) {
      case "atm":
        return "ATM Withdrawal";
      case "safiricom":
        return "Safaricom Withdrawal";
      case "airtel":
        return "Airtel Withdrawal";
      case "payzarcAgent":
        return "Payzarc Agent Withdrawal";
      default:
        return mobileMoneyWithdrawSelected ? "Mobile Money" : "Withdraw Money";
    }
  };

  const getAddMoneyTitle = () => {
    switch (selectedAddOption) {
      case "bank":
        return "Bank Deposit";
      case "mpesa":
        return "Mpesa Deposit";
      case "airtel":
        return "Airtel Deposit";
      case "payzarc":
        return "Payzarc Deposit";
      default:
        return mobileMoneySelected ? "Mobile Money" : "Add Money";
    }
  };

  const getSendMoneyTitle = () => {
    switch (sendMethod) {
      case "email":
        return "Send Money via Email";
      case "phone":
        return "Send Money via Phone";
      default:
        return "Send Money";
    }
  };

  return (
    <div className={styles.homeContainer}>
      {/* Left Column */}
      <div className={styles.leftColumn}>
        {/* Wallet Card */}
        <div className={styles.walletCard}>
          <div className={styles.walletHeader}>
            <span className={styles.walletTitle}>Wallet Balance</span>
            {/* <div className={styles.balanceLabel}>Available Balance</div> */}
            {loadingBalance ? (
              <div className={styles.loading}>Loading balance...</div>
            ) : balanceError ? (
              <p className={styles.errorWallet}>{balanceError}</p>
            ) : (
              // <div className={styles.walletBalanceContainer}>
              //   <button
              //     className={styles.eyeIcon}
              //     onClick={toggleBalance}
              //     type="button"
              //     aria-label={showBalance ? "Hide balance" : "Show balance"}
              //   >
              //     {showBalance ? <EyeOff size={20} /> : <Eye size={20} />}
              //   </button>
              // </div>
              <div className={styles.balanceContainer}>
                <button
                  className={styles.eyeIcon}
                  onClick={toggleBalance}
                  type="button"
                >
                  {showBalance ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            )}
          </div>
          <div className={styles.balanceValue}>
            {/* {showBalance ? "KES 25,450.00" : "KES * *, * * *. * *"} */}
            <span
              className={`${styles.balanceText} ${
                showBalance ? styles.balanceVisible : styles.balanceHidden
              }`}
            >
              {showBalance
                ? `${balanceData?.currency || "KES"} ${formattedBalance}`
                : "••••••••"}
            </span>
          </div>
          <div className={styles.walletActions}>
            <div className={styles.actionButton}>
              {/* <FontAwesomeIcon icon={Plus} className={styles.actionIcon} /> */}
              <Plus strokeWidth={3} className={styles.actionIcon} />
              <span className={styles.actionText}>Add Money</span>
            </div>
            <div className={styles.actionButton}>
              {/* <FontAwesomeIcon icon={ArrowBigUp} className={styles.actionIcon} /> */}
              <ArrowUpIcon strokeWidth={3} className={styles.actionIcon} />
              <span className={styles.actionText}>Send Money</span>
            </div>
            <div className={styles.actionButton}>
              <ArrowDownIcon strokeWidth={3} className={styles.actionIcon} />
              <span className={styles.actionText}>Withdraw</span>
            </div>
            <div className={styles.actionButton}>
              <Users strokeWidth={3} className={styles.actionIcon} />
              <span className={styles.actionText}>Groups</span>
            </div>
          </div>
        </div>

        {/* This Month Overview */}
        <div className={styles.overviewSection}>
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTitle}>This Month Overview</span>
          </div>
          <div className={styles.overviewGrid}>
            <div className={styles.overviewCard}>
              <div className={styles.overviewLabel}>Total Income</div>
              {/* <div className={styles.miniChart}>

              </div> */}
              <div className={styles.overviewValue}>+KES 24,500.00</div>
              <div className={`${styles.overviewTrend} ${styles.trendUp}`}>
                <FontAwesomeIcon icon={TrendingUp} /> 12.5% vs last month
              </div>
            </div>
            <div className={styles.overviewCard}>
              <div className={styles.overviewLabel}>Total Expenses</div>
              {/* <div className={styles.miniChart}>
               
              </div> */}
              <div className={styles.overviewValue}>-KES 10,000.00</div>
              <div className={`${styles.overviewTrend} ${styles.trendDown}`}>
                <FontAwesomeIcon icon={TrendingDown} /> 8.3% vs last month
              </div>
            </div>
            <div className={styles.overviewCard}>
              <div className={styles.overviewLabel}>Net Savings</div>
              {/* <div className={styles.miniChart}>
                
              </div> */}
              <div className={styles.overviewValue}>+KES 14,500.00</div>
              <div className={`${styles.overviewTrend} ${styles.trendUp}`}>
                <FontAwesomeIcon icon={TrendingUp} /> 18.7% vs last month
              </div>
            </div>
          </div>
        </div>

        {/* Savings Groups */}
        <div className={styles.groupsSection}>
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTitle}>Savings Groups & Chamas</span>
            <span className={styles.viewAll}>View all</span>
          </div>
          <div className={styles.groupsList}>
            <div className={styles.groupItem}>
              <div className={styles.groupInfo}>
                <div
                  className={styles.groupIcon}
                  style={{ backgroundColor: "#065f46", color: "#34d399" }}
                >
                  {/* <FontAwesomeIcon icon={Users} /> */}
                  <Users strokeWidth={3} />
                </div>
                <div>
                  <div className={styles.groupName}>Savers Club</div>
                  <div className={styles.groupMembers}>12 Members</div>
                </div>
              </div>
              <div className={styles.groupBalance}>
                KES 62,500.00
                {/* <FontAwesomeIcon icon={ChevronRight} /> */}
                <ChevronRight strokeWidth={3} />
              </div>
            </div>
            <div className={styles.groupItem}>
              <div className={styles.groupInfo}>
                <div
                  className={styles.groupIcon}
                  style={{ backgroundColor: "#92400e", color: "#fbbf24" }}
                >
                  {/* <FontAwesomeIcon icon={Briefcase} /> */}
                  <Briefcase strokeWidth={3} />
                </div>
                <div>
                  <div className={styles.groupName}>Business Partners</div>
                  <div className={styles.groupMembers}>8 Members</div>
                </div>
              </div>
              <div className={styles.groupBalance}>
                KES 150,000.00
                {/* <FontAwesomeIcon icon={ChevronRight} /> */}
                <ChevronRight strokeWidth={3} />
              </div>
            </div>
            <div className={styles.groupItem}>
              <div className={styles.groupInfo}>
                <div
                  className={styles.groupIcon}
                  style={{ backgroundColor: "#3730a3", color: "#818cf8" }}
                >
                  {/* <FontAwesomeIcon icon={Users} /> */}
                  <Users strokeWidth={3} />
                </div>
                <div>
                  <div className={styles.groupName}>Family Chama</div>
                  <div className={styles.groupMembers}>6 Members</div>
                </div>
              </div>
              <div className={styles.groupBalance}>
                KES 45,300.00
                {/* <FontAwesomeIcon icon={ChevronRight} /> */}
                <ChevronRight strokeWidth={3} />
              </div>
            </div>
          </div>
          <div className={styles.createGroupBtn}>+ Create or Join Group</div>
        </div>
      </div>

      {/* Right Column */}
      <div className={styles.rightColumn}>
        {/* Quick Send */}
        <div className={styles.quickSendCard}>
          <div className={styles.quickSendTitle}>Quick Send</div>
          <div className={styles.inputGroup}>
            <div className={styles.inputLabel}>
              <img
                src="https://flagcdn.com/w40/ke.png"
                className={styles.countryFlag}
                alt="KE"
              />
              <span>+254</span>
              <FontAwesomeIcon
                icon={ChevronRight}
                style={{ transform: "rotate(90deg)", fontSize: "10px" }}
              />
              <input
                type="text"
                placeholder="Phone number or email"
                className={styles.inputField}
                value={quickRecipient}
                onChange={(e) => setQuickRecipient(e.target.value)}
              />
              {/* <FontAwesomeIcon icon={Briefcase} style={{ color: "#94a3b8" }} /> */}
              <Briefcase strokeWidth={3} style={{ color: "#94a3b8" }} />
            </div>
          </div>
          {/* <div className={styles.inputGroup}>
            <div className={styles.inputLabel}>
              <select
                className={styles.quickCountrySelect}
                value={quickDestinationCountry.name}
                onChange={(e) => {
                  const selected = sortedCountries.find(
                    (c) => c.name === e.target.value,
                  );
                  setQuickDestinationCountry(selected);
                }}
              >
                {sortedCountries.map((country) => (
                  <option key={country.code} value={country.name}>
                    {country.flag} {country.name}
                  </option>
                ))}
              </select>

              <ChevronRight strokeWidth={3} className={styles.countryChevron} />
            </div>
          </div> */}
          <div className={styles.inputLabel}>
            <img
              src={`https://flagcdn.com/w40/${quickDestinationCountry.flag.toLowerCase()}.png`}
              alt={quickDestinationCountry.name}
              className={styles.countryFlag}
            />

            <select
              className={styles.quickCountrySelect}
              value={quickDestinationCountry.name}
              onChange={(e) => {
                const selected = sortedCountries.find(
                  (c) => c.name === e.target.value,
                );
                setQuickDestinationCountry(selected);
              }}
            >
              {sortedCountries.map((country) => (
                <option key={country.code} value={country.name}>
                  {country.name}
                </option>
              ))}
            </select>

            <ChevronRight strokeWidth={3} className={styles.countryChevron} />
          </div>

          {/* <div className={styles.amountDisplay}>
            <div className={styles.amountBox}>
              <span className={styles.amountVal}>0.00</span>
              <div
                style={{ display: "flex", alignItems: "center", gap: "8px" }}
              >
                <img
                  src="https://flagcdn.com/w40/us.png"
                  className={styles.countryFlag}
                  alt="US"
                />
                <span className={styles.currencyCode}>USD</span>
              </div>
            </div>
            <div className={styles.amountBox}>
              <span className={styles.amountVal}>0.00</span>
              <span className={styles.currencyCode}>KES</span>
            </div>
          </div> */}
          <div className={styles.amountDisplay}>
            <div className={styles.amountBox}>
              <div className={styles.amountGroup}>
                <input
                  type="number"
                  min="0"
                  max="1000000"
                  // step="1"
                  placeholder="0.00"
                  className={styles.inputField}
                  value={quickAmount}
                  onChange={(e) => setQuickAmount(e.target.value)}
                />
              </div>

              <div
                style={{ display: "flex", alignItems: "center", gap: "8px" }}
              >
                <img
                  src={`https://flagcdn.com/w40/${quickDestinationCountry.flag.toLowerCase()}.png`}
                  className={styles.countryFlag}
                  alt={quickDestinationCountry.name}
                />
                <span className={styles.currencyCode}>
                  {quickDestinationCountry.currency}
                </span>
              </div>
            </div>

            <div className={styles.amountBox}>
              <div className={styles.amountGroup}>
                <input
                  type="text"
                  className={styles.inputField}
                  value={equivalentAmount}
                  readOnly
                />
              </div>

              <span className={styles.currencyCode}>{destInfo.currency}</span>
            </div>
          </div>
          <button className={styles.sendBtn} onClick={handleQuickSend}>
            Send Money <Send strokeWidth={2} />
          </button>
        </div>

        {/* Latest Transactions */}
        <div className={styles.transactionsCard}>
          <div className={styles.sectionHeader}>
            <span className={styles.sectionTitle}>Latest Transactions</span>
            <span className={styles.viewAll}>View all</span>
          </div>
          <div className={styles.transactionsList}>
            <TransactionItem
              icon={<Tv />}
              name="DStv Subscription"
              date="Today · 09:32 AM"
              amount="- USD 142.99"
              isNegative={true}
              iconBg="#450a0a"
              iconColor="#f87171"
            />
            <TransactionItem
              icon={<Users />}
              name="Payzarc Club Contribution"
              date="Yesterday · 04:18 PM"
              amount="+ KES 2,400.00"
              isNegative={false}
              iconBg="#064e3b"
              iconColor="#34d399"
            />
            <TransactionItem
              icon={<Handshake />}
              name="Dubai Partners"
              date="May 20 · 09:41 AM"
              amount="- KES 10,000.00"
              isNegative={true}
              iconBg="#422006"
              iconColor="#fbbf24"
            />
            <TransactionItem
              icon={<ShoppingCart />}
              name="Naivas Supermarket"
              date="May 20 · 08:15 AM"
              amount="- KES 1,850.00"
              isNegative={true}
              iconBg="#1e1b4b"
              iconColor="#818cf8"
            />
            <TransactionItem
              icon={<University />}
              name="Salary from ABC Ltd"
              date="May 19 · 11:30 AM"
              amount="+ KES 25,000.00"
              isNegative={false}
              iconBg="#0c4a6e"
              iconColor="#38bdf8"
            />
          </div>
          <div className={styles.viewAllTx}>View all transactions</div>
        </div>
      </div>
    </div>
  );
}

function TransactionItem({
  icon,
  name,
  date,
  amount,
  isNegative,
  iconBg,
  iconColor,
}) {
  return (
    <div className={styles.transactionItem}>
      <div className={styles.groupInfo}>
        <div
          className={styles.txIcon}
          style={{ backgroundColor: iconBg, color: iconColor }}
        >
          {icon}
        </div>
        <div className={styles.txInfo}>
          <div className={styles.txName}>{name}</div>
          <div className={styles.txDate}>{date}</div>
        </div>
      </div>
      <div className={styles.txAmount}>
        <span
          className={`${styles.amtMain} ${isNegative ? styles.amtNegative : styles.amtPositive}`}
        >
          {amount}
        </span>
      </div>
    </div>
  );
}

const faHandshake = {
  // prefix: "fas",
  iconName: "handshake",
  icon: [640, 512, [], "f2b5", "..."],
};

export default Home;
