import React, { useState, useEffect } from "react";
import TransactionDetails from "./TransactionDetails";
import { countries } from "../../utility/countries";
import styles from "./History.module.css";
import { djangoApis } from "../../utility/axiosInstance";

function History({ selectedTransaction, openDetailsPopup, closeDetailsPopup }) {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Filter states
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  const fetchTransactions = async () => {
    setLoading(true);
    setError(null);

    let rawToken = localStorage.getItem("accessToken");

    if (!rawToken) {
      // setError("Please login again. No token found.");
      setLoading(true);
      return;
    }

    // SUPER CLEAN TOKEN - this is the most important part
    let token = rawToken
      .replace(/^["']|["']$/g, "") // remove outer quotes
      .replace(/\\"/g, "") // remove escaped quotes
      .replace(/Bearer\s*/i, "") // remove any existing "Bearer " prefix
      .trim();

    console.log(
      "Cleaned token (first 50 chars):",
      token.substring(0, 50) + "...",
    );

    console.log("🔑 Raw token length:", rawToken.length);
    console.log(
      "🔑 Cleaned token (first 80 chars):",
      token.substring(0, 80) + "...",
    );

    try {
      const params = {};
      if (dateFrom) params.date_from = dateFrom;
      if (dateTo) params.date_to = dateTo;
      // You can add searchTerm later if your backend supports it
      // if (searchTerm.trim()) params.search = searchTerm.trim();

      const response = await djangoApis.system1.get(
        "/api/transactions/history/",
        {
          params,
          headers: {
            Authorization: `Bearer ${token}`,
          },
        },
      );

      console.log("FULL RESPONSE:", response);
      console.log("RESPONSE DATA:", response.data);

      setTransactions(response.data);

      const data = response.data;
      setTransactions(
        Array.isArray(data) ? data : data.results || data.transactions || [],
      );
      setError(null);
    } catch (err) {
      console.error("❌ Full error:", err.response?.data || err);
      setError(
        err.response?.data?.detail ||
          err.message ||
          "Failed to load transactions",
      );
      setTransactions([]);
    } finally {
      setLoading(false);
    }
  };

  // Load on mount
  useEffect(() => {
    fetchTransactions();
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    fetchTransactions();
  };

  const getFlagEmoji = (countryName) => {
    const country = countries.find(
      (c) => c.name.toLowerCase() === countryName?.toLowerCase(),
    );
    return country ? country.flag : "🏳️";
  };

  const formatAmount = (tx) => {
    return `$${Number(tx.amount || 0).toFixed(2)}`;
  };

  return (
    <div className={styles.section}>
      {/* Filter Section */}
      <div className={styles.dateGroup}>
        <div className={styles.buttonGroup}>
          <input
            type="text"
            placeholder="Email or phone no"
            className={styles.inputField}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className={styles.dateInput}>
          <input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className={styles.dateInput}
          />
        </div>
        <div className={styles.dateInput}>
          <input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className={styles.dateInput}
          />
        </div>
        <button
          className={styles.searchButton}
          onClick={handleSearch}
          title="Load Transactions"
          disabled={loading}
        >
          {loading ? (
            "..."
          ) : (
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 24 24"
              fill="currentColor"
            >
              <path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 0 0 1.48-5.34c-.47-2.78-2.79-5-5.59-5.34a6.505 6.505 0 0 0-7.27 7.27c.34 2.8 2.56 5.12 5.34 5.59a6.5 6.5 0 0 0 5.34-1.48l.27.28v.79l4.25 4.25c.41.41 1.08.41 1.49 0 .41-.41.41-1.08 0-1.49L15.5 14z" />
            </svg>
          )}
        </button>
      </div>

      {/* Table Section */}
      <div className={styles.tableContainer}>
        {loading && (
          <p style={{ color: "#94a3b8", textAlign: "center", padding: "20px" }}>
            Loading transactions...
          </p>
        )}

        {error && (
          <p style={{ color: "#ef4444", textAlign: "center", padding: "20px" }}>
            {error}
          </p>
        )}

        {!loading && !error && transactions.length === 0 && (
          <p style={{ color: "#94a3b8", textAlign: "center", padding: "40px" }}>
            No transactions found for the selected period.
          </p>
        )}

        {transactions.length > 0 && (
          <table className={styles.table}>
            <thead>
              <tr>
                <th>Date</th>
                <th>Ref. No.</th>
                <th>Name</th>
                <th>Country</th>
                <th>Amt</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((tx, index) => {
                const status =
                  tx.status ||
                  (tx.transaction_type === "receive" ? "Received" : "Paid");
                const country = tx.country || tx.recipient_country || "Kenya";

                return (
                  <tr key={tx.id || tx.transaction_code || index}>
                    <td>{tx.created_at || tx.date || tx.timestamp}</td>
                    <td>{tx.transaction_code || tx.refNo || tx.reference}</td>
                    <td>
                      {tx.name || tx.recipient_name || tx.sender_name || "N/A"}
                    </td>
                    <td>
                      <span className={styles.flagContainer}>
                        <span className={styles.flagEmoji}>
                          {getFlagEmoji(country)}
                        </span>
                        <span className={styles.countryName}>{country}</span>
                      </span>
                    </td>
                    <td>{formatAmount(tx)}</td>
                    <td>
                      <button
                        className={styles.statusButton}
                        onClick={() => openDetailsPopup(tx)}
                      >
                        {status}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Popup */}
      {selectedTransaction && (
        <TransactionDetails
          transaction={selectedTransaction}
          closeDetailsPopup={closeDetailsPopup}
        />
      )}
    </div>
  );
}

export default History;
